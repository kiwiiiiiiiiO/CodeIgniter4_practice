<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class ClassmateSeeder extends Seeder
{
    public function run()
    {
        //seed some user todo data.
        $now   = date("Y-m-d H:i:s");

        $data = [
            [
                'c_name'    => 'Example title',
                'c_email'  => 'Example email',
                'c_birth'  => 'Example birth',
                'created_at' => $now,
                'updated_at' => $now,
            ],
        ];

        $this->db->table('classmate')->insertBatch($data);
    }
}
