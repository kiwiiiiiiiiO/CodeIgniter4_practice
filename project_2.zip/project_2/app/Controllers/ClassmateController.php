<?php

namespace APP\Controllers;

use App\Controllers\BaseController;
use App\Models\ClassmateModel;
use CodeIgniter\API\ResponseTrait;


class ClassmateController extends BaseController
{   
    use ResponseTrait;
    protected ClassmateModel $classmateModel;

    public function __construct()
    {
        $this->classmateModel = new ClassmateModel();
    }

    public function index(){
        // final all 
        $classmateModel = $this -> classmateModel-> findAll();
        // print_r($classmateModel);
        return $this -> respond([
            "msg" => "success",
            "data" => $classmateModel
        ]);
    }

    public function view(){
       return view('classmate');
    } 

    // show 單筆 資料
    public function show(?int $key = null){
        
        if($key === null ){
            return $this->failNotFound("Enter the classmate key");
        }
        // database find data 
        $classmate = $this->classmateModel->find($key);

        if ($classmate === null){
            return $this->failNotFound("Classmate is not found");
        }
        return $this->respond([
            "msg" => "success",
            "data" => $classmate
        ]);
    }
    // delete 單筆資料
    // ?
    public function delete(?int $key = null){
        if($key === null){
            return $this->failNotFound("Key is not found");
        }
        if($this->classmateModel->find($key) === null){
            return $this->failNotFound("This data is not found");
        }
        // key != null && find data 
        $isDeleted = $this->classmateModel->delete($key);

        if($isDeleted === false){
            return $this->fail("Delete failed");
        }else{
            return $this->respond([
                "msg" => "Delete succcessfully"
            ]);
        }
    }

    // create
    public  function create(){
        // ??: : null coalescing operator
        // $result = $expr1 ?? $expr2;   (當 $expr1 不為 null，return $expr1，否則 return $expr2。)
        $data = $this-> request->getJSON();
        $name = $data->name  ?? null;
        $email = $data->email ?? null;
        $birth = $data->birth ?? null;
        
        if($name ===null || $email === null || $birth === null){
            return $this-> fail("Pass in data is not found", 404);
        }
        if($name === "" || $email === "" || $birth === ""){
            return $this-> fail("Pass in data is not found", 404);
        }

        // insert data 
        $createdKey = $this -> classmateModel->insert([
            "c_name" => $name, 
            "c_email" => $email,
            "c_birth" => $birth, 
            "created_at" => date("Y-m-d H:i:s"),
            "updated_at" => date("Y-m-d H:i:s")
        ]);

        if($createdKey === false){
            return $this->fail("create failed");
        }else{
            return $this->respond([
                "msg" => "create successfully",
                "data" => $createdKey
            ]);
        }

    }

    // update 單筆資料
    public function update(?int $key = null){
        $data = $this-> request->getJSON();
        $name = $data->name  ?? null;
        $email = $data->email ?? null;
        $birth = $data->birth ?? null;
        if($key === null){
            return $this->failNotFound("Key is not found");
        }
        $willUpdateData = $this->classmateModel->find($key);
        if($willUpdateData === null){
            return $this->failNotFound("This data is not found");
        }

        // update data 

        if($name !== null){
            $willUpdateData["c_name"] = $name;
        }
        if($email !== null){
            $willUpdateData["c_email"] = $email;
        }
        if($birth !== null){
            $willUpdateData["c_birth"] = $birth;
        }

        // update
        $isUpdated = $this ->classmateModel->update($key, $willUpdateData);

        if($isUpdated === false){
            return $this->fail("Updated failed");
        }else{
            return $this->respond([
                "msg" => "Update successfully"
            ]);
        }
    }
}


?>