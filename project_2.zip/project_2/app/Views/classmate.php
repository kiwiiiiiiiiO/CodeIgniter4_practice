<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/axios/1.4.0/axios.min.js"></script>
<script type=text/javascript>

     $(document).ready(function(){
        classmateComponent.index();
    });
 
    let classmateComponent = {
        index:function(){
            axios.get('http://localhost:8080/classmate')
                .then((response) =>{
                    console.log(response.data.data);
                    RenderPage(response.data.data);
                }).catch((error) => console.log(error))
        },
        show:function(key){
            console.log(key);
            axios.get('http://localhost:8080/classmate/'+key)
                .then((response) => {
                console.log(response.data.data);
            }).catch((error) => console.log(error))
        }, 
        update:function(key, data){
            console.log(key);
            axios.put('http://localhost:8080/classmate/'+key, JSON.stringify(data))
                .then((response) => console.log(response))
                .catch((error) => console.log(error))
        }, 
        delete: function(key){
            axios.delete('http://localhost:8080/classmate/'+key)
                .then((response) => console.log(response))
                .catch((error) => console.log(error))
        }, 
        create: function(data){
            axios.post('http://localhost:8080/classmate/', JSON.stringify(data))
                .then((response) => console.log(response))
                .catch((error) => console.log(error))
        }
    }

    const RenderPage = (data) => {
        for(let i=0 ; i<data.length ; i++){
            const tr = document.createElement("tr");
            const count_td = document.createElement("td");
            count_td.innerHTML = i+1;
            const id_td = document.createElement("td");
            id_td.innerHTML = data[i].c_id;
            // input
            const name_td = document.createElement("td");
            const name_td_input = document.createElement("input");
            name_td_input.className= "name_td_input";
            name_td_input.value = data[i].c_name;
            name_td_input.readOnly = true; 
            name_td.appendChild(name_td_input);
            // input
            const email_td = document.createElement("td");
            const email_td_input = document.createElement("input");
            email_td_input.className= "email_td_input";
            email_td_input.value = data[i].c_email;
            email_td_input.readOnly = true; 
            email_td.appendChild(email_td_input);
            // input 
            const birth_td =  document.createElement("td");
            const birth_td_input = document.createElement("input");
            birth_td_input.className= "birth_td_input";
            birth_td_input.value = data[i].c_birth;
            birth_td_input.readOnly = true; 
            birth_td_input.type = "date";
            birth_td.appendChild(birth_td_input);

            const edit_td =  document.createElement("td");
            edit_td.id = "edit_td";
            const delete_btn =  document.createElement("button");
            delete_btn.className = "Deletebtn";
            delete_btn.innerHTML = "DELETE";
            delete_btn.id = data[i].c_id;
            const update_btn =  document.createElement("button");
            update_btn.className = "Update_btn";
            update_btn.innerHTML = "UPDATE";
            update_btn.id = data[i].c_id;
            // append atttribute 
            edit_td.appendChild( delete_btn );
            edit_td.appendChild(  update_btn );
            tr.appendChild( count_td );
            tr.appendChild( id_td );
            tr.appendChild( name_td );
            tr.appendChild(  email_td );
            tr.appendChild( birth_td);
            tr.appendChild( edit_td );
            document.getElementById("data_body").appendChild(tr);
        }
        // delete one data 
        let deletebtn = document.getElementsByClassName("Deletebtn");
        for(let i =0 ; i<deletebtn.length;i++){
            deletebtn[i].addEventListener("click", function(){
                console.log(deletebtn[i].id);
                classmateComponent.delete( parseInt(deletebtn[i].id, 10 ));
                alert("Delete Successfully!");
                location.reload();
            });
        }
        let Updated = false;
 //update data 
let name_td_input = document.getElementsByClassName("name_td_input");
let email_td_input = document.getElementsByClassName("email_td_input");
let birth_td_input = document.getElementsByClassName("birth_td_input");
let updatebtn = document.getElementsByClassName("Update_btn");
for(let i =0 ; i < updatebtn.length;i++){
    updatebtn[i].addEventListener("click", function(){
        // console.log( updatebtn[i].id);
        if(Updated == false){
            // readonly=true 狀態，使用者 進行更改
            name_td_input[i].readOnly = false;
            email_td_input[i].readOnly = false;
            birth_td_input[i].readOnly = false;
            Updated = true;
        }else{  // ==true 
            //  readonly=false 狀態，使用者已更改完，進行除存
            let idvalue = parseInt( updatebtn[i].id, 10);
            let namevalue =  name_td_input[i].value; 
            let emailvalue =  email_td_input[i].value; 
            let birthvalue =  birth_td_input[i].value; 
            if(namevalue == null || namevalue =="" || emailvalue ==null || emailvalue =="" || birthvalue ==null || birthvalue ==""){
                alert("Update input can't be null ");
            }else{
                let data = {
                    "name":namevalue,
                    "email":emailvalue, 
                    "birth":birthvalue
                }
                console.log( data );
                classmateComponent.update(idvalue, data);
                // alert("Update Successfully!");
                // location.reload();
            }
        }
    });
}

    
    }
    
    

</script>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome to CodeIgniter 4!</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body{
            text-align: center;
            height: 100vh;
        }
        .centerDiv{
            margin:0 auto;
        }
        table{
            width: 50%;
            margin:0 auto;
            background-color: #eeeeee;
            padding:10px;
        }
        table, td{
            border-bottom: 3px solid #616161;
            border-radius: 3px;
        }
        #createbtn_submit, #CreateBtn{
            width : 100px;
            height: 35px;
            font-size: 20px;
            border: 1px solid #00BFA5;
            color:white;
            border-radius: 6px;
            box-shadow: 0 5px 20px rgba(92, 99, 105,0.4);
            background-color: #00BFA5;
        }
        #CreateBtn:hover{
            background-color: #1DE9B6;
            box-shadow: 0 5px 20px rgba(92, 99, 105,0.8);
        }
        #createbtn_submit:hover{
            background-color: #1DE9B6;
            box-shadow: 0 5px 20px rgba(92, 99, 105,0.8);
        }
        #edit_td{
            display:flex;
            justify-content: space-between;  
            padding-left:50px;
            padding-right:50px;
        }
        .Deletebtn{
            width : 100px;
            height: 35px;
            font-size: 20px;
            border: 1px solid #DD2C00;
            margin-right: 10px;;
            color:white;
            border-radius: 6px;
            box-shadow: 0 5px 20px rgba(92, 99, 105,0.4);
            background-color: #DD2C00;
        }
        .Deletebtn:hover{
            background-color: #FF3D00;
            box-shadow: 0 5px 20px rgba(92, 99, 105,0.8);
        }
        .Update_btn{
            width : 100px;
            height: 35px;
            font-size: 20px;
            border: 1px solid #FFAB00;
            color:white;
            border-radius: 6px;
            box-shadow: 0 5px 20px rgba(92, 99, 105,0.4);
            background-color: #FFAB00;
        }
        .Update_btn:hover{
            background-color: #FFC400;
            box-shadow: 0 5px 20px rgba(92, 99, 105,0.8);
        }

        /* Modal  */
        .modal {
            display: none; /* Hidden by default */
            position: fixed; /* Stay in place */
            z-index: 1; /* Sit on top */
            left: 0;
            top: 0;
            width: 100%; /* Full width */
            height: 100%; /* Full height */
            overflow: auto; /* Enable scroll if needed */
            background-color: rgb(0,0,0); /* Fallback color */
            background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
        }

            /* Modal Content/Box */
        .modal-content {
            background-color: #fefefe;
            margin: 15% auto; /* 15% from the top and centered */
            padding: 20px;
            border: 1px solid #888;
            border-radius: 6px;
            width: 30%; /* Could be more or less, depending on screen size */
            min-width: 300px;
        }

            /* The Close Button */
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class ="centerDiv">
        <h2> NKNU SEM Classmates List <button id="CreateBtn">Create</button>  </h2>
        <table class="table table-hover" >
            <thead>
                <tr>
                    <!-- table head -->
                    <th scope="col">#</th>
                    <th scope="col">ID</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Birth</th>
                    <th scope="col">Edit</th>
                </tr>
            </thead>

            <tbody id="data_body">
                <!--  append chiled -->
            </tbody>
        </table>
    </div>
<!-- create -->
    <!-- The Modal -->
    <div id="myModal" class="modal">
        <!-- Modal content -->
        <div class="modal-content">
            <span class="close">&times;</span> 
            <h3> Add Classmate </h3>
            <a>Name</a><br>
            <input id="newname_input" type="text"><br><br>
            <a>Email</a><br>
            <input id="newemail_input" type="text"><br><br>
            <a>birth</a><br>
            <input id="newbirth_input" type="date"><br><br>
            <button id="createbtn_submit" >Submit</button>
        </div>
    </div>
</body>
<script>
// ceeate _ modal 
var modal = document.getElementById("myModal");
var btn = document.getElementById("CreateBtn");
var span = document.getElementsByClassName("close")[0];
btn.onclick = function() {
  modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}


// create data
let createbtn_submit = document.getElementById("createbtn_submit");
createbtn_submit.addEventListener("click", function(){
    let new_name = document.getElementById("newname_input").value; 
    let new_email = document.getElementById("newemail_input").value; 
    let new_birth = document.getElementById("newbirth_input").value; 
    if(new_name == null || new_email == null || new_birth == null || new_name=="" || new_email=="" || new_birth =="") {
        alert("Create input can't be null !");
    }else{
        let data = {
            "name": new_name,
            "email": new_email,
            "birth": new_birth
        };
        classmateComponent.create(data);
        // 新增成功 reload 
        alert("Created Successfully");
        location.reload();
    }
});


</script>
</html>