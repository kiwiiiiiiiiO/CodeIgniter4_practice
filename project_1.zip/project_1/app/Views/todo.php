<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/axios/1.4.0/axios.min.js"></script>
<script type=text/javascript>
    $(document).ready(function(){
        todoComponent.index();
    });

    let todoComponent = {
        index: function(){
            axios.get('http://localhost:8080/todo')
                .then((response) =>{
                    console.log(response.data.data);
                    RenderPage(response.data.data);
                }).catch((error) => console.log(error))
        },
        // $routes->get('todo', 'TodoListController::index');
        show: function(key){
            console.log(key);
            axios.get('http://localhost:8080/todo/'+key)
                .then((response) => {
                console.log(response.data.data);
            }).catch((error) => console.log(error))
        },
        // $routes->get('todo/(:num)', 'TodoListController::show/$1');
        create: function(data){
            axios.post('http://localhost:8080/todo', JSON.stringify(data))
                .then((response) => console.log(response))
                .catch((error) => console.log(error))
        },

        // $routes ->post('todo','TodoListController::create');
        update: function(key, data){
            axios.put('http://localhost:8080/todo/'+key, JSON.stringify(data))
                .then((response) => console.log(response))
                .catch((error) => console.log(error))
        },
        // $routes -> put('todo/(:num)','TodoListController::update/$1');
        delete: function(key){
            axios.delete('http://localhost:8080/todo/'+key)
                .then((response) => console.log(response))
                .catch((error) => console.log(error))
        }
        // $routes -> delete('todo/(:num)','TodoListController::delete/$1');
    }
    const RenderPage = (data) => {
        // 有幾行 data
        for(let i=0 ; i<data.length; i++){
            //create element 
            const tr = document.createElement("tr");
            const key_td = document.createElement("td");
            const title_td = document.createElement("td");
            const content_td = document.createElement("td");
            const edit_td = document.createElement("td");
            const delete_btn  = document.createElement("button");
            const update_td = document.createElement("td");
            const update_btn_a  = document.createElement("button");
            // set element
            key_td.innerHTML = data[i].t_key;
            title_td.innerHTML =  data[i].t_title;
            content_td.innerHTML = data[i].t_content;
            delete_btn.innerHTML = "DELETE";
            update_btn_a.innerHTML = "UPDATE"
            delete_btn.className = "DeleteBtn";
            update_btn_a.className = "UpdateBtn_a"
            update_btn_a.id = data[i].t_key;
            delete_btn.id = data[i].t_key;
            edit_td.id = "edit_td";
            // append child 
            tr.appendChild( key_td );
            tr.appendChild( title_td );
            tr.appendChild( content_td );
            tr.appendChild( edit_td);
            edit_td.appendChild( delete_btn );
            edit_td.appendChild( update_btn_a );
            document.getElementById("data_body").appendChild(tr);
        }

        // delete data
        let deletebtn = document.getElementsByClassName("DeleteBtn");
        for(let i =0 ; i<deletebtn.length;i++){
            deletebtn[i].addEventListener("click", function(){
                console.log(deletebtn[i].id);
                todoComponent.delete( parseInt(deletebtn[i].id, 10 ));
                alert("Delete Successfully!");
                location.reload();
            });
        }

        //update data_ alter key 
        let updatebtn_a = document.getElementsByClassName("UpdateBtn_a");
        for(let i =0 ; i < updatebtn_a.length;i++){
            updatebtn_a[i].addEventListener("click", function(){
                // console.log(updatebtn_a[i].id);
                document.getElementById("Update_t_key_input").value = updatebtn_a[i].id+"";
            });
        }
    }
</script>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Table Lab</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body{
            text-align: center;
            height: 100vh;
        }
        .center{
            margin:0 auto;
        }
        table{
            width: 50%;
            margin:0 auto;
            background-color: #eeeeee;
        }
        table, tr, th, td{
            border: 3px solid #616161;
            border-radius: 3px;
        }
        td{
            padding: 5px;
        }
        #CreateArea{
            display:flex;
            flex-wrap:wrap;
            align-content:center;
            flex-direction: column;
            justify-content: space-between;
            padding: 20px;
        }
        #UpdateArea{
            display:flex;
            flex-wrap:wrap;
            align-content:center;
            flex-direction: column;
            justify-content: space-between;  
            padding: 20px;
        }
        #CreateArea a, button{
            width : 200px;
        }
        #CreateArea button{
            width : 200px;
            height: 35px;
            border: 1px solid #198754;
            border-radius: 6px;
            background-color: #198754;
            color:white;
            box-shadow: 0 5px 20px rgba(92, 99, 105,0.4);
        }
        #CreateArea button:hover{
            width : 200px;
            height: 35px;
            background-color:#42ba96;
            box-shadow: 0 5px 20px rgba(92, 99, 105,0.8);
        }
        #CreateArea input{
            width : 200px;
            height: 30px;
            font-size: 15px;
            text-align: center;
        }
        #UpdateArea a, button{
            width : 200px;
        }
        #UpdateArea input{
            width : 200px;
            height: 30px;
            font-size: 15px;
            text-align: center;
        }
        #UpdateArea button{
            width : 200px;
            height: 35px;
            border: 1px solid #ffc107;
            background-color:#ffc107;
            color:white;
            border-radius: 6px;
            box-shadow: 0 5px 20px rgba(92, 99, 105,0.4);
        }
        #UpdateArea button:hover{
            background-color: #ffd24a;
            box-shadow: 0 5px 20px rgba(92, 99, 105,0.8);
        }
        .UpdateBtn_a{
            width : 200px;
            height: 35px;
            border: 1px solid #ff6d00;
            background-color:#ff6d00;
            color:white;
            border-radius: 6px;
            box-shadow: 0 5px 20px rgba(92, 99, 105,0.4);
        }
        .UpdateBtn_a:hover{
            background-color: #fa8228;
            box-shadow: 0 5px 20px rgba(92, 99, 105,0.8);
        }
        .DeleteBtn{
            width : 200px;
            height: 35px;
            border: 1px solid #DC4C64;
            background-color:#DC4C64;
            color:white;
            border-radius: 6px;
            margin-right: 10px;
            box-shadow: 0 5px 20px rgba(92, 99, 105,0.4);
        }
        .DeleteBtn:hover{
            background-color: #d95d72;
            box-shadow: 0 5px 20px rgba(92, 99, 105,0.8);
        }
        #edit_td{
            display:flex;
            justify-content: space-between;  
            padding-left:50px;
            padding-right:50px;
        }
    </style>

</head>
<body>
    <div class="center">
        <h1> Todo_List </h1>
        <div>
            <table>
                <thead>
                    <tr>
                        <th colspan="4">Todo Database</th>
                    </tr>
                    <tr>
                        <th>t_key</th>
                        <th>t_title</th>
                        <th>t_content</th>

                        <th id="Edit_th">Edit</th>
                    </tr>
                </thead>
                <tbody id="data_body">
                    <!-- append child  -->
                </tbody>
            </table>
        <div>
        <div id="CreateArea">
            <h3>Create data</h3>
            <a>t_title</a> <input type="text" id="Create_title_input" placeholder="new title" >
            <a>t_content</a> <input type="text" id="Create_content_input"  placeholder="new content"><br>
            <button id="CreateBtn">Submit</button>
        </div>
        <div id="UpdateArea">
            <h3>Update data</h3>
            <a>Alter t_key</a> 
            <input type="text" id="Update_t_key_input" readonly="readonly" placeholder="Click Update Button!" ><br>
            <!--  -->
            <a> New t_title</a> <input type="text" id="Update_title_input" placeholder="update title">
            <a> New t_content</a> <input type="text" id="Update_content_input" placeholder="update content"><br>
            <button id="UpdateBtn">Submit</button>
        </div>
    </div>

</body>
<script>

  // create data 
  let createbtn = document.getElementById("CreateBtn");
    createbtn.addEventListener("click", function(){
        let title_data = document.getElementById("Create_title_input").value; 
        let content_data = document.getElementById("Create_content_input").value;
        if(title_data == null || title_data =="" || content_data == null || content_data ==""){
            alert("Create input can't be null !");
        }else{
            let data = {
            "title":title_data, 
            "content":content_data
            };
            todoComponent.create(data);
            // 新增成功 reload 
            alert("Created Successfully");
            location.reload();
        }
    });

    // update data _ update
    let updatebtn = document.getElementById("UpdateBtn");
    updatebtn.addEventListener("click", function(){

       let alter_id = parseInt(document.getElementById("Update_t_key_input").value,10); 
       let new_title = document.getElementById("Update_title_input").value; 
       let new_content = document.getElementById("Update_content_input").value; 
        console.log( alter_id);
        console.log( new_title );
        console.log( new_content );
        if( new_title == null ||  new_title == "" || new_content== "" ||  new_content== null){
            alert("Update input can't be null ")
        }else{
            
            let data = {
                "title":new_title,
                "content":new_content
            }
            todoComponent.update(alter_id, data);
            alert("Update Successfully!");
            location.reload();
        }
    });
</script>
</html>
